//: Playground - noun: a place where people can play

import UIKit

let intArray = [1,2,3,4,5]
let resultArray = intArray.map{num in num*num}
print(resultArray)

extension Array{
    func customMap<T>(transform:Element->T) -> [T] {
        var result:[T] = []
        for num in self {
            result.append(transform(num))
        }
        return result
    }
}

let secondArray = intArray.customMap{num in num*num}
//func customMap<T>(transform:Element->T) -> [T]  
//这是函数签名
