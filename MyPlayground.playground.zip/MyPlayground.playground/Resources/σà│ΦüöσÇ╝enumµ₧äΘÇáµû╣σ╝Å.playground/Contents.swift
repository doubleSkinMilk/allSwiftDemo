//: Playground - noun: a place where people can play

import UIKit

enum Device{
    case Phone(name:String,screenSize:CGSize)
    case Watch(name:String,screenSize:CGSize)
    case Tablet(name:String,screenSize:CGSize)
    
    
    private static var initializers:[String:(name:String,screenSize:CGSize)-> Device] = {
        return ["Phone":Device.Phone,"Watch":Device.Watch,"Tablet":Device.Tablet]
    }()
    
    static func fromDefault(rowValue:String,name:String,screenSize:CGSize)->Device?{
        return initializers[rowValue]?(name: name,screenSize: screenSize)
    }
    
}

let iphone = Device.Phone(name: "iphone", screenSize: CGSize(width: 100, height: 100))

let appleWatch = Device.fromDefault("Watch", name: "appleWatch",
                                    screenSize: CGSize(width: 100, height: 100))
let apple = Device.Watch(name: "appleWatch", screenSize: CGSize(width: 100, height: 100))

enum  people:String {
    case teacher,student,mom
}

let me = people(rawValue: "people")
