//
//  videoTableViewCell.swift
//  p3_简单的视频播放
//
//  Created by 范译文 on 16/3/20.
//  Copyright © 2016年 范译文. All rights reserved.
//

import UIKit

class videoTableViewCell: UITableViewCell {

    @IBOutlet weak var playImage: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var sourceLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
