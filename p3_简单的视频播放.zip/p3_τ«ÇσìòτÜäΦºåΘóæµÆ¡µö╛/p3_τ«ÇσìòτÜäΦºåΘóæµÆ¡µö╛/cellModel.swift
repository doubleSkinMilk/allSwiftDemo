//
//  File.swift
//  p3_简单的视频播放
//
//  Created by 范译文 on 16/3/20.
//  Copyright © 2016年 范译文. All rights reserved.
//

import Foundation

struct video{
    let image:String
    let title:String
    let source:String
}