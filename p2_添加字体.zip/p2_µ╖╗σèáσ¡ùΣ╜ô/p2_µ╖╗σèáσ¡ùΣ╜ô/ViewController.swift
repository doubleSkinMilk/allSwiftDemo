//
//  ViewController.swift
//  p2_添加字体
//
//  Created by 范译文 on 16/3/19.
//  Copyright © 2016年 范译文. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var changeBtn: UIButton!
    @IBOutlet weak var TextTableView: UITableView!
    
    let textData = ["唐僧师徒西天取经，有天，唐僧饿了说:","“悟空，为师饿了，你去化点斋饭吧！”悟空很快回来，手里只拿了几根黄瓜。","唐僧：“这是到哪里了？”悟空：“方圆百里都是黄瓜地，我也不知道是哪里!“","唐僧：“扶我起来，想必到了女儿国了！"]
    let fontNames = ["MFTongXin_Noncommercial-Regular", "MFJinHei_Noncommercial-Regular", "MFZhiHei_Noncommercial-Regular"]
    var fontIndex = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        changeBtn.layer.cornerRadius = 50
        TextTableView.dataSource = self
        TextTableView.delegate = self
    }

    @IBAction func changeFont(sender: AnyObject) {
        fontIndex = (fontIndex+1)%3
        TextTableView.reloadData()
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return textData.count
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cell  = TextTableView.dequeueReusableCellWithIdentifier("FontCell", forIndexPath: indexPath)
        cell.textLabel?.text = textData[indexPath.row]
        cell.textLabel?.textColor = UIColor.whiteColor()
        cell.textLabel?.numberOfLines = 0
        cell.textLabel?.font = UIFont(name: fontNames[fontIndex], size: 20)
        
        return cell
    
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

