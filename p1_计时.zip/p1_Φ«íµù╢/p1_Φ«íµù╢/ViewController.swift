//
//  ViewController.swift
//  p1_计时
//
//  Created by 范译文 on 16/3/19.
//
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var begin: UIButton!
    @IBOutlet weak var pause: UIButton!
    @IBOutlet weak var timelabe: UILabel!
    
    var timer = NSTimer()
    var isPlayIng = false
    /// 为存储属性设置属性观察器
    var Counter = 0.0{
        willSet(newValue){
            timelabe.text = String(format: "%0.1f", newValue)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        cornerButton()
        loadData()
    }
    
    override func preferredStatusBarStyle() -> UIStatusBarStyle {
        return UIStatusBarStyle.LightContent
    }
    
    func updataTime(){
        Counter = Counter + 0.1
    }
    
    func loadData(){
        timelabe.text = String(Counter)
        timelabe.adjustsFontSizeToFitWidth = true
    }
    
    func cornerButton(){

        let cornerPath = UIBezierPath(roundedRect: begin.bounds, byRoundingCorners: .AllCorners, cornerRadii:begin.bounds.size)
        
        let maskLayer = CAShapeLayer()
        maskLayer.frame = begin.bounds
        maskLayer.path = cornerPath.CGPath
        
        let maskLayer2 = CAShapeLayer()
        maskLayer2.frame = begin.bounds
        maskLayer2.path = cornerPath.CGPath
        
        begin.layer.mask = maskLayer
        pause.layer.mask = maskLayer2
    }
    
    @IBAction func start(sender: AnyObject) {
        guard !isPlayIng else{return}
        
        begin.enabled = false
        pause.enabled = true
        timer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self,
            selector: Selector("updataTime"), userInfo: nil, repeats: true)
        isPlayIng = true
    }
    
    @IBAction func stop(sender: AnyObject) {
        begin.enabled = true
        pause.enabled = false
        timer.invalidate()
        isPlayIng = false
    }
    
    @IBAction func reset(sender: AnyObject) {
        timer.invalidate()
        isPlayIng = false
        Counter = 0.0
        begin.enabled = true
        pause.enabled = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

