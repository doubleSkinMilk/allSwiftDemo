//
//  leftVC.swift
//  p4_相机
//
//  Created by 范译文 on 16/3/20.
//  Copyright © 2016年 范译文. All rights reserved.
//

import UIKit

class leftVC: UIViewController {

}
