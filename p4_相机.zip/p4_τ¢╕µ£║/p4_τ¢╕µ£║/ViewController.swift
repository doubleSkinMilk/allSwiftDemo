//
//  ViewController.swift
//  p4_相机
//
//  Created by 范译文 on 16/3/20.
//  Copyright © 2016年 范译文. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var scrollView: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        UIApplication.sharedApplication().statusBarHidden = true
        
        let leftVc = leftVC(nibName:"leftVC",bundle: nil)
        
        self.addChildViewController(leftVc)
        self.scrollView.addSubview(leftVc.view)
        leftVc.didMoveToParentViewController(self)
//        leftVc.view.frame.size = self.view.bounds.size
        
        let cameraVc = cameraVC(nibName:"cameraVC",bundle: nil)
        
        self.addChildViewController(cameraVc)
        self.scrollView.addSubview(cameraVc.view)
        cameraVc.didMoveToParentViewController(self)
        cameraVc.view.frame.origin = CGPoint(x: self.view.bounds.size.width, y: 0)
        
        self.scrollView.contentSize = CGSize(width: self.view.bounds.size.width*2,
            height: self.view.bounds.size.height)
    
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

